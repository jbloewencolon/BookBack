// strategies.js - Core Logic Shared Library

// --- PART A: BOOK DETECTION STRATEGIES ---
const BOOK_SCOPES = {
    amazon: {
        check: (url) => /\/(dp|gp\/product)\//.test(url),
        title: ['#productTitle', '#ebooksProductTitle', '#title', 'h1'],
        author: ['#bylineInfo', '.author', '.contributorNameID'],
        isbn: ['#detailBullets_feature_div', '#prodDetails']
    },
    indigo: {
        check: (url) => /\/books\//.test(url),
        title: ['h1.product-title', 'h1'],
        author: ['.contributor-name', '.author']
    },
    barnes: {
        check: (url) => url.includes('barnesandnoble.com'),
        title: ['h1.pdp-header-title', 'h1'],
        author: ['#key-contributors', '.contributors']
    },
    goodreads: {
        check: (url) => url.includes('goodreads.com'),
        title: ['h1[data-testid="bookTitle"]', 'h1'],
        author: ['span[data-testid="name"]', '.authorName']
    },
    bookshop: {
        check: (url) => url.includes('bookshop.org'),
        title: ['h1', '.book-title'],
        author: ['.book-author', 'h2']
    },
    thriftbooks: {
        check: (url) => url.includes('thriftbooks.com'),
        title: ['h1'],
        author: ['.WorkMeta-author']
    },
    generic: {
        check: () => true, // Fallback
        title: ['h1'],
        author: ['.author', '.byline', '.contributor']
    }
};

const BookScanner = {
    cleanText: (text) => {
        if (!text) return "";
        return text
            .replace(/\s+/g, ' ')
            // Remove common suffix clutter safely
            .replace(/\(Author\)|\(Editor\)|\(Illustrator\)/gi, '')
            // Remove trailing pipes/colons only if they are at the very end
            .replace(/[:|]\s*$/, '')
            .trim();
    },

    isBookPage: () => {
        const url = window.location.href;
        
        // 1. URL Pattern Check
        if (/\/dp\/|\/gp\/product\/|\/book\/|\/books\//.test(url)) return true;
        if (url.includes('/w/') || url.includes('/p/books/')) return true; 
        if (/(978|979)\d{10}/.test(url)) return true;
        
        // 2. Breadcrumb Check (Amazon)
        const crumbs = document.getElementById('wayfinding-breadcrumbs_feature_div');
        if (crumbs && crumbs.innerText.includes('Books')) return true;

        // 3. Metadata Check
        if (document.querySelector('meta[property="og:type"][content="book"]')) return true;
        if (document.querySelector('meta[property="og:isbn"]')) return true;
        
        return false;
    },

    extract: () => {
        // 1. Try JSON-LD (Structured Data) - Most Accurate
        const scripts = document.querySelectorAll('script[type="application/ld+json"]');
        for (let script of scripts) {
            try {
                const data = JSON.parse(script.innerText);
                const item = Array.isArray(data) ? 
                    data.find(d => d['@type'] === 'Book' || d.isbn) : 
                    (data['@type'] === 'Book' || data.isbn ? data : null);
                
                if (item) {
                    let author = item.author;
                    if (Array.isArray(author)) author = author.map(a => a.name).join(' ');
                    else if (typeof author === 'object') author = author.name;

                    return {
                        title: BookScanner.cleanText(item.name),
                        author: BookScanner.cleanText(author),
                        isbn: item.isbn
                    };
                }
            } catch (e) {}
        }

        // 2. Visual Fallback
        const host = window.location.hostname;
        let config = BOOK_SCOPES.generic;

        if (host.includes('amazon')) config = BOOK_SCOPES.amazon;
        else if (host.includes('indigo')) config = BOOK_SCOPES.indigo;
        else if (host.includes('barnes')) config = BOOK_SCOPES.barnes;
        else if (host.includes('goodreads')) config = BOOK_SCOPES.goodreads;
        else if (host.includes('bookshop')) config = BOOK_SCOPES.bookshop;
        else if (host.includes('thriftbooks')) config = BOOK_SCOPES.thriftbooks;

        let title, author;
        
        for (let sel of config.title) {
            const el = document.querySelector(sel);
            if (el) { title = el.innerText; break; }
        }
        for (let sel of config.author) {
            const el = document.querySelector(sel);
            if (el) { author = el.innerText; break; }
        }

        if (title) {
            return {
                title: BookScanner.cleanText(title),
                author: BookScanner.cleanText(author)
            };
        }
        return null;
    }
};

window.BookScanner = BookScanner;