// options.js - v17.0 (Fixed IDs and Error Reporting)
document.addEventListener('DOMContentLoaded', async () => {
    // FIX 1: Match the ID from options.html (newLibraryUrl, not newLib)
    const list = document.getElementById('libraryList');
    const input = document.getElementById('newLibraryUrl'); 
    const status = document.getElementById('status');
    const help = document.querySelector('.manual-explainer');

    // Load
    const libs = await window.getLibraries();
    render(libs);

    function render(items) {
        list.innerHTML = '';
        items.forEach((lib, idx) => {
            const div = document.createElement('div');
            div.className = 'lib-row';
            div.innerHTML = `
                <input type="text" value="${lib.searchUrl}" data-idx="${idx}">
                <button class="lib-remove" data-idx="${idx}">X</button>
            `;
            list.appendChild(div);
        });

        document.querySelectorAll('.lib-remove').forEach(b => {
            b.onclick = async () => {
                items.splice(b.dataset.idx, 1);
                render(items);
                await window.saveLibraries(items); 
            };
        });
    }

    // --- PERMISSION HANDLER ---
    async function requestAndDetect() {
        // Clear previous status
        status.innerText = "";
        status.style.color = "#333";

        let url = input.value.trim();
        if (!url) {
            status.innerText = "Please paste a URL first.";
            status.style.color = "red";
            return;
        }
        
        if (!url.startsWith('http')) url = 'https://' + url;
        
        // 1. Calculate Origin
        let origin;
        try {
            origin = new URL(url).origin + "/*";
        } catch(e) { 
            // FIX 2: No more silent failure on bad URLs
            status.innerText = "Invalid URL format.";
            status.style.color = "red";
            return; 
        }

        status.innerText = "Checking Permissions...";
        
        // 2. Request Permission DIRECTLY to avoid losing user gesture
        // We skip 'contains' check to ensure the popup triggers reliably
        if (typeof chrome !== 'undefined' && chrome.permissions) {
             chrome.permissions.request({ origins: [origin] }, (granted) => {
                 // Check for browser runtime error (e.g. user closed popup)
                 if (chrome.runtime.lastError) {
                     console.warn(chrome.runtime.lastError);
                 }

                 if (granted) {
                     runDetection(url);
                 } else {
                     status.innerText = "Permission Denied. Cannot scan.";
                     status.style.color = "red";
                 }
             });
        } else {
            // Fallback for browsers without permissions API
            runDetection(url);
        }
    }

    // --- ACTUAL DETECTION ---
    async function runDetection(url) {
        status.innerText = "Scanning website...";
        status.style.color = "blue";

        try {
            const result = await window.detectLibrary(url);
            
            if (result && result.searchUrl) {
                libs.push(result);
                render(libs);
                await window.saveLibraries(libs);
                
                input.value = '';
                status.innerText = "Success! Library Added.";
                status.style.color = "green";
                
                if (result.isGeneric) {
                    // It worked, but fell back to manual mode
                    status.innerText += " (Manual Mode)";
                    if(help) help.style.display = 'block';
                }
            } else {
                status.innerText = "Could not find search bar.";
                status.style.color = "orange";
                if(help) help.style.display = 'block';
            }
        } catch (e) {
            console.error(e);
            status.innerText = "Error: " + (e.message || "Network Fail");
            status.style.color = "red";
            if(help) help.style.display = 'block';
        }
    }

    // Bind the click event
    const detectBtn = document.getElementById('detectBtn');
    if (detectBtn) {
        detectBtn.onclick = requestAndDetect;
    } else {
        console.error("Critical: Detect button not found in HTML");
    }

    const manualBtn = document.getElementById('addManualBtn');
    if (manualBtn) {
        manualBtn.onclick = () => {
            libs.push({ searchUrl: "" });
            render(libs);
            if(help) help.style.display = 'block';
        };
    }

    const saveBtn = document.getElementById('saveBtn');
    if (saveBtn) {
        saveBtn.onclick = async () => {
            const currentData = [];
            document.querySelectorAll('.lib-row input').forEach(inp => {
                if (inp.value.trim().length > 5) currentData.push({ searchUrl: inp.value.trim() });
            });
            await window.saveLibraries(currentData);
            status.innerText = "Saved!";
            status.style.color = "green";
            setTimeout(() => status.innerText = '', 2000);
        };
    }
});