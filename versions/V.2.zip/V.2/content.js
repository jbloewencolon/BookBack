// content.js - v24.0 (Persistence Mode)

(async function() {
    
    // Dependencies Check
    if (!window.extractBookDetails || !window.createWidget || !window.injectWidget) return;

    // CORE: Try to find book info + inject widget
    const tryInject = async () => {
        // 1. If widget exists, check if it's still attached to DOM
        const existing = document.getElementById('bookback-widget');
        if (existing && document.body.contains(existing)) return true;

        // 2. Try to get book details
        const details = window.extractBookDetails();
        if (!details) return false;

        // 3. Get saved libraries
        const libraries = await window.getLibraries();

        // 4. Create widget
        let widget;
        if (!libraries || libraries.length === 0) {
            widget = window.createLibraryFinder();
        } else {
            widget = window.createWidget(details, libraries);
        }

        // 5. Inject
        window.injectWidget(widget);
        
        // Return true only if injection worked
        return !!document.getElementById('bookback-widget');
    };

    // STARTUP
    // We run a "pulse" that checks every 2 seconds if the widget is still there.
    // This counters Amazon wiping the DOM.
    const isUrlMatch = /\/(dp|gp\/product|book|books)\//.test(window.location.href);

    if (isUrlMatch || window.isBookPage()) {
        
        // Initial Try
        await tryInject();

        // The "Zombie" Interval: Revive the widget if Amazon kills it
        // Runs every 1.5 seconds, stops after 30 seconds to save battery
        let attempts = 0;
        const pulse = setInterval(async () => {
            attempts++;
            const success = await tryInject();
            if (attempts > 20) clearInterval(pulse); // Stop after 30s
        }, 1500);
    }
})();