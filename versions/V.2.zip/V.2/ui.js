// ui.js - Widget rendering (Target Update)
const browserAPI = typeof browser !== 'undefined' ? browser : chrome;

function createWidget(bookDetails, libraries) {
  const container = document.createElement('div');
  container.id = 'bookback-widget';
  
  const title = bookDetails.title.length > 50 ? bookDetails.title.substring(0, 50) + '...' : bookDetails.title;
  
  container.innerHTML = `
    <div class="bb-header-row">
      <div class="bb-icon">↩</div>
      <div class="bb-content">
        <div class="bb-label">BOOKBACK</div>
        <div class="bb-title">${title}</div>
      </div>
    </div>
    <div class="bb-desc">Available in your ${libraries.length > 1 ? 'libraries' : 'library'}?</div>
    <a href="#" class="bb-btn bb-green">Check Availability</a>
  `;
  
  const btn = container.querySelector('.bb-btn');
  
  btn.onclick = (e) => {
      e.preventDefault();
      [...libraries].reverse().forEach(lib => {
          const query = encodeURIComponent(bookDetails.title + " " + (bookDetails.author || ""));
          const url = lib.searchUrl.replace('{{query}}', query);
          window.open(url, '_blank');
      });
  };
  
  return container;
}

function createLibraryFinder() {
  const container = document.createElement('div');
  container.id = 'bookback-widget';
  
  container.innerHTML = `
    <div class="bb-header-row">
      <div class="bb-icon">↩</div>
      <div class="bb-content">
        <div class="bb-label">BOOKBACK</div>
        <div class="bb-title">Support The Commons</div>
      </div>
    </div>
    <div class="bb-desc">Locate your nearest library (Privacy Safe):</div>
    <input type="text" class="bb-input" placeholder="City, State or Zip">
    <a href="#" class="bb-btn bb-green">Search Maps</a>
  `;
  
  const input = container.querySelector('input');
  const btn = container.querySelector('.bb-btn');
  
  const doSearch = () => {
    const loc = input.value.trim();
    if (loc) {
      const url = `https://duckduckgo.com/?q=${encodeURIComponent(loc + " public library")}&ia=maps`;
      window.open(url, '_blank');
    }
  };
  
  btn.onclick = (e) => { e.preventDefault(); doSearch(); };
  input.addEventListener('keypress', (e) => { if (e.key === 'Enter') doSearch(); });
  
  return container;
}

function injectWidget(widget) {
  // Broad list of Amazon container IDs
  const targets = [
    document.getElementById('combinedBuyBox'),
    document.getElementById('unifiedBuyBox'),
    document.getElementById('buybox'),
    document.getElementById('mediaNoAccordion'), // Hardcover/Paperback specific
    document.getElementById('exports_popover'),
    document.querySelector('.buy-box'),
    document.querySelector('#rightCol'),
    document.querySelector('.product-detail-buying-container'),
    document.querySelector('.buying-container')
  ];
  
  const target = targets.find(el => el && el.offsetParent !== null);
  
  if (target) {
    target.insertBefore(widget, target.firstChild);
  } else {
    // If we can't find a home, float it fixed
    widget.classList.add('bb-fixed');
    document.body.appendChild(widget);
  }
}

window.createWidget = createWidget;
window.createLibraryFinder = createLibraryFinder;
window.injectWidget = injectWidget;