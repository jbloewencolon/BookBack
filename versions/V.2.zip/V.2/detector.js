// detector.js - v2.0 (Aggressive Text Scraping)
const browserAPI = typeof browser !== 'undefined' ? browser : chrome;

let _cachedDetails = null;

const cleanText = (text) => {
    if (!text) return "";
    return text
        .replace(/\s+/g, ' ') 
        .replace(/[:|]\s*Amazon\..*$/i, '') 
        .replace(/[:|]\s*Books.*$/i, '') 
        .replace(/\|.*$/i, '')
        .replace(/\(Author\)|\(Editor\)|\(Foreword\)/gi, '')
        .replace(/A Novel/gi, '') 
        .trim();
};

function isBookPage() {
    const url = window.location.href;
    
    // 1. URL Check (Fastest)
    if (/\/dp\/|\/gp\/product\/|\/book\/|\/books\//.test(url)) return true;

    // 2. Metadata Check (JSON-LD)
    const scripts = document.querySelectorAll('script[type="application/ld+json"]');
    for (let script of scripts) {
        try {
            const data = JSON.parse(script.innerText);
            const item = Array.isArray(data) ? 
                data.find(d => d['@type'] === 'Book' || d.isbn) : 
                (data['@type'] === 'Book' || data.isbn ? data : null);
            if (item) return true;
        } catch (e) { }
    }

    // 3. VISUAL CHECK (The Project 2 logic that makes it work)
    // Amazon Breadcrumbs
    const breadcrumbs = document.getElementById('wayfinding-breadcrumbs_feature_div');
    if (breadcrumbs && breadcrumbs.innerText.includes('Books')) return true;

    // Product Details Text Scan
    const details = document.getElementById('detailBullets_feature_div') || document.getElementById('prodDetails');
    if (details) {
        const text = details.innerText.toLowerCase();
        if (text.includes('isbn') || text.includes('hardcover') || text.includes('paperback')) return true;
    }

    // OpenGraph Fallback
    const metaType = document.querySelector('meta[property="og:type"]')?.content;
    if (metaType === 'book') return true;

    return false;
}

function extractBookDetails() {
    if (_cachedDetails) return _cachedDetails;

    let title, author;

    // A. Try JSON-LD first (Best Quality)
    const scripts = document.querySelectorAll('script[type="application/ld+json"]');
    for (let script of scripts) {
        try {
            const data = JSON.parse(script.innerText);
            const item = Array.isArray(data) ? 
                data.find(d => d['@type'] === 'Book' || d.isbn) : 
                (data['@type'] === 'Book' || data.isbn ? data : null);
            
            if (item) {
                title = item.name;
                if (Array.isArray(item.author)) author = item.author.map(a => a.name).join(' ');
                else if (item.author) author = item.author.name || item.author;
            }
        } catch (e) {}
    }

    // B. Visual Scraping (Fallback)
    if (!title) {
        // Amazon specific
        const amzTitle = document.getElementById('productTitle') || document.getElementById('ebooksProductTitle');
        if (amzTitle) title = amzTitle.innerText;
        
        // Generic H1
        if (!title) {
            const h1 = document.querySelector('h1');
            if (h1) title = h1.innerText;
        }
    }

    if (!author) {
        const byline = document.getElementById('bylineInfo') || document.querySelector('.author') || document.querySelector('.contributorNameID');
        if (byline) author = byline.innerText;
    }

    if (title) {
        _cachedDetails = { 
            title: cleanText(title), 
            author: cleanText(author) 
        };
        return _cachedDetails;
    }
    
    return null;
}

window.isBookPage = isBookPage;
window.extractBookDetails = extractBookDetails;