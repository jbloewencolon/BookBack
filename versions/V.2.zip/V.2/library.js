// library.js - v2.0 (Deep Scan & Recursive Search)
const browserAPI = typeof browser !== 'undefined' ? browser : chrome;

const VENDOR_SIGNATURES = {
  "vega": { check: ["iiivega", "vegapattern", "vega-root"], url: "/search?searchText={{query}}" },
  "encore": { check: ["/iii/encore", "app_encore"], url: "/iii/encore/search/C__S{{query}}" },
  "bibliocommons": { check: ["bibliocommons"], url: "/v2/search?query={{query}}&searchType=smart" },
  "sirsidynix": { check: ["/client/", "enterprise", "sirsidynix"], url: "/client/en_US/default/search/results?qu={{query}}" },
  "polaris": { check: ["polaris"], url: "/polaris/search/searchresults.aspx?ctx=1.1033.0.0.6&type=Keyword&term={{query}}" },
  "koha": { check: ["koha"], url: "/cgi-bin/koha/opac-search.pl?q={{query}}" },
  "evergreen": { check: ["evergreen", "opac/results"], url: "/eg/opac/results?query={{query}}" },
  "overdrive": { check: ["overdrive", "libbyapp"], url: "/search?query={{query}}" }
};

// Helper: Fix double slashes in URLs
const cleanUrl = (url) => url.replace(/([^:]\/)\/+/g, "$1");

// Helper: Find a "Catalog" link on a generic homepage
function findCatalogLink(doc, currentUrl) {
    const origin = new URL(currentUrl).origin;
    const keywords = ['catalog', 'search collection', 'find books', 'opac', 'login', 'my account'];
    
    const links = Array.from(doc.querySelectorAll('a[href]'));
    for (let a of links) {
        const text = a.innerText.toLowerCase();
        const href = a.getAttribute('href');
        
        // Skip javascript/anchors
        if (href.includes('javascript') || href.startsWith('#')) continue;

        if (keywords.some(k => text.includes(k))) {
            if (href.startsWith('http')) return href;
            return href.startsWith('/') ? origin + href : origin + '/' + href;
        }
    }
    return null;
}

// Helper: Identify vendor from URL/HTML
function identifyVendor(url, html) {
    const origin = new URL(url).origin;
    
    // Fast Track: SirsiDynix Client URL
    if (url.includes('/client/')) {
        const match = url.match(/\/client\/([^?#]+)/);
        if (match) {
            let path = match[1];
            if (path.endsWith('/')) path = path.slice(0, -1);
            return cleanUrl(origin + "/client/" + path + "/search/results?qu={{query}}");
        }
    }

    for (const [name, vendor] of Object.entries(VENDOR_SIGNATURES)) {
        if (vendor.check.some(sig => url.includes(sig) || html.includes(sig))) {
            return cleanUrl(origin + vendor.url);
        }
    }
    return null;
}

// Main Detection Function
async function detectLibrary(url) {
  if (!url) return { searchUrl: "", isGeneric: true };
  if (!url.startsWith('http')) url = 'https://' + url;
  
  try {
      // 1. Initial Fetch
      let response = await fetch(url).catch(e => null);
      if (!response) throw new Error("Network Error");
      
      let text = await response.text();
      let finalUrl = response.url;
      let doc = new DOMParser().parseFromString(text, 'text/html');

      // 2. Check current page
      let searchUrl = identifyVendor(finalUrl, text);
      
      // 3. DEEP SCAN: If not found, look for "Catalog" link and follow it
      if (!searchUrl) {
          const catalogLink = findCatalogLink(doc, finalUrl);
          if (catalogLink) {
              console.log("Following link to catalog:", catalogLink);
              try {
                  response = await fetch(catalogLink);
                  text = await response.text();
                  finalUrl = response.url;
                  doc = new DOMParser().parseFromString(text, 'text/html');
                  
                  // Check the new destination
                  searchUrl = identifyVendor(finalUrl, text);
              } catch(e) { console.warn("Deep scan fetch failed"); }
          }
      }

      // 4. Fallback: Scrape Forms (on whichever page we ended up on)
      if (!searchUrl) {
          searchUrl = scrapeSearchForm(doc, finalUrl);
      }

      if (searchUrl) {
          return { searchUrl: searchUrl };
      }

      throw new Error("No system detected");

  } catch (e) {
      console.log("Detection failed, defaulting to manual.");
      return { searchUrl: url, isGeneric: true };
  }
}

function scrapeSearchForm(doc, url) {
  const forms = doc.querySelectorAll('form');
  const priorityParams = ['qu', 'term', 'q', 'query', 'searchText', 'k'];
  
  for (let form of forms) {
    if (form.getAttribute('action')?.match(/login|auth/i)) continue;
    
    const inputs = form.querySelectorAll('input[type="text"], input[type="search"]');
    for (let inp of inputs) {
      if (priorityParams.includes(inp.name)) {
        const baseUrl = new URL(url);
        let action = form.getAttribute('action') || "";
        
        let finalAction = action.startsWith('http') ? action : 
                          action.startsWith('/') ? baseUrl.origin + action : 
                          baseUrl.origin + '/' + action;
        
        finalAction = cleanUrl(finalAction);
        const sep = finalAction.includes('?') ? '&' : '?';
        return `${finalAction}${sep}${inp.name}={{query}}`;
      }
    }
  }
  return null;
}

window.detectLibrary = detectLibrary;