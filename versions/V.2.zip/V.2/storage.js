// storage.js - Data persistence layer
const browserAPI = typeof browser !== 'undefined' ? browser : chrome;

async function getLibraries() {
  return new Promise((resolve) => {
    browserAPI.storage.local.get(['libraries'], (result) => {
      let libs = result.libraries || [];
      // Sanitize
      libs = libs.filter(l => l.searchUrl && l.searchUrl.length > 5);
      resolve(libs);
    });
  });
}

async function saveLibraries(libraries) {
  return new Promise((resolve) => {
    browserAPI.storage.local.set({ libraries }, () => {
      resolve();
    });
  });
}

// Expose globally
window.getLibraries = getLibraries;
window.saveLibraries = saveLibraries;